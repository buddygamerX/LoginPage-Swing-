
package loginpage;

public class LoginPage {
    public static void main(String[] args) {
       Login Loginframe=new Login();
       Loginframe.setVisible(true);
       Loginframe.pack();
       Loginframe.setLocationRelativeTo(null);
    }
    
}